namespace Rockaway.WebApp.Pages;

public class IndexModel : PageModel {

	public void OnGet() {

	}
}