global using AngleSharp;
global using Microsoft.AspNetCore.Mvc.Testing;
global using Shouldly;
global using Xunit;