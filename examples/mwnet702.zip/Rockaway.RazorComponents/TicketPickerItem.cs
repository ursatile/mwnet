﻿namespace Rockaway.RazorComponents;

public class TicketPickerItem {
	public Guid Id { get; set; }
	public string Name { get; set; }
	public decimal Price { get; set; }
}
