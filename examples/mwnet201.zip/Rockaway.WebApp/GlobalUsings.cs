// Global using directives

global using Rockaway.WebApp.Services;
global using Rockaway.WebApp.Data;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore;
global using Rockaway.WebApp.Models;