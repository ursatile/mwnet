// Global using directives

global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore;
global using Rockaway.WebApp.Data;
global using Rockaway.WebApp.Data.Entities;
global using Rockaway.WebApp.Models;
global using Rockaway.WebApp.Services;