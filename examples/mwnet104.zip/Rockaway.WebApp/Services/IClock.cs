namespace Rockaway.WebApp.Services;
public interface IClock {
    DateTime Now { get; }

}