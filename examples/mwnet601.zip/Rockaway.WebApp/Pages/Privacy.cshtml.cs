namespace Rockaway.WebApp.Pages;

public class PrivacyModel : PageModel {

	public void OnGet() {
	}
}